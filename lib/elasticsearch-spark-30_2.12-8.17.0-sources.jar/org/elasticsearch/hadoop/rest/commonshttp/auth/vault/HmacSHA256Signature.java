package org.elasticsearch.hadoop.rest.commonshttp.auth.vault;


import org.apache.shiro.codec.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class HmacSHA256Signature {

    public static final String HMAC_SHA256 = "HmacSHA256";


    public String getSignName() {
        return HMAC_SHA256;
    }


    public String sign(String data, String accessKey) {
        try {
            Mac mac = Mac.getInstance(HMAC_SHA256);
            SecretKeySpec signingKey = new SecretKeySpec(accessKey.getBytes(), HMAC_SHA256);
            mac.init(signingKey);
            byte[] signData = mac.doFinal(data.getBytes());
            return Base64.encodeToString(signData);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("not support " + HMAC_SHA256);
        } catch (InvalidKeyException e) {
            throw new RuntimeException("Speicified access secret is not valid.");
        }
    }
}
