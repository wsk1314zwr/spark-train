package org.elasticsearch.hadoop.rest.commonshttp.auth.vault;


import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * http utils
 */
public class HttpUtils {


    public static final Logger logger = LoggerFactory.getLogger(HttpUtils.class);

    public static String post(ObjectNode jsonObj, String url, Map<String, String> header) {
        HttpPost httpPost = null;
        String responseContent = null;
        try {
            CloseableHttpClient httpclient = HttpClients.createDefault();
            httpPost = new HttpPost(url);

            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(60 * 1000)
                    .setConnectionRequestTimeout(60 * 1000)
                    .setSocketTimeout(60 * 1000)
                    .setRedirectsEnabled(true)
                    .build();
            httpPost.setConfig(requestConfig);

            if (!Objects.isNull(header)) {
                for (String key : header.keySet()) {
                    httpPost.setHeader(key, header.get(key));
                }
            }
            httpPost.setHeader("Content-Type", "application/json; charset=utf-8");
            httpPost.setHeader("Connection", "Close");
            String sessionId = getUuid();
            httpPost.setHeader("SessionId", sessionId);

            StringEntity entity = new StringEntity(jsonObj.toString(), StandardCharsets.UTF_8);
            entity.setContentEncoding("UTF-8");

            entity.setContentType("application/json");
            httpPost.setEntity(entity);
            HttpResponse response;
            response = httpclient.execute(httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode != HttpStatus.SC_OK) {
                logger.error("request error: " + statusCode);
            } else {
                HttpEntity responseEntity = response.getEntity();
                if (responseEntity != null) {
                    responseContent = EntityUtils.toString(responseEntity, "UTF-8");
                } else {
                    logger.warn("http entity is null");
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if (httpPost != null) {
                try {
                    httpPost.releaseConnection();
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        return responseContent;
    }

    public static String getUuid() {
        return UUID.randomUUID().toString().replace("-", "");
    }

}
