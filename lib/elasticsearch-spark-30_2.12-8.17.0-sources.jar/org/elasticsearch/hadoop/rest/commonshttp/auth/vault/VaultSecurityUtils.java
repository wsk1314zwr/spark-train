package org.elasticsearch.hadoop.rest.commonshttp.auth.vault;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class VaultSecurityUtils {

    public static final String VERSION = "version";

    public static final String VERSION_VALUE = "1.0.0";

    public static final String APPKEY = "appKey";

    public static final String TIMESTAMP = "timestamp";

    public static final String XREQNONCE = "xReqNonce";

    public static final String APPSECRET = "appSecret";

    public static final String SIGNATURE = "signature";

    private String vaultAppcodeValue;

    private String vaultGetewayUrlValue;

    private String vaultGetewayAppkeylValue;

    private String vaultGetewayAppsecretValue;

    public final static ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public final static Logger log = LoggerFactory.getLogger(VaultSecurityUtils.class);

    public VaultSecurityUtils(String vaultAppcodeValue, String vaultGetewayUrlValue, String vaultGetewayAppkeylValue, String vaultGetewayAppsecretValue) {
        assert vaultAppcodeValue != null;
        assert vaultGetewayUrlValue != null;
        assert vaultGetewayAppkeylValue != null;
        assert vaultGetewayAppsecretValue != null;

        this.vaultAppcodeValue = vaultAppcodeValue;
        this.vaultGetewayUrlValue = vaultGetewayUrlValue;
        this.vaultGetewayAppkeylValue = vaultGetewayAppkeylValue;
        this.vaultGetewayAppsecretValue = vaultGetewayAppsecretValue;
    }

    private HashMap<String, String> getHeaders(long timestamp, String uuid, String signature) {
        HashMap<String, String> headers = new HashMap<>();
        headers.put(TIMESTAMP, String.valueOf(timestamp));
        headers.put(VERSION, VERSION_VALUE);
        headers.put(APPKEY, vaultGetewayAppkeylValue);
        headers.put(XREQNONCE, uuid);
        headers.put(SIGNATURE, signature);
        return headers;
    }


    public String decryptBySecretAlias(String secretAlias) {
        return decryptBySecretAlias(secretAlias, vaultAppcodeValue);
    }


    public String decryptBySecretAlias(String secretAlias, String appCode) {
        long timestamp = System.currentTimeMillis();
        String uuid = HttpUtils.getUuid();
        String signature = getSignature(timestamp, uuid);
        ObjectNode body = OBJECT_MAPPER.createObjectNode();
        body.put("appCode", appCode);
        body.put("secretAlias", secretAlias);
        HashMap<String, String> headers = getHeaders(timestamp, uuid, signature);
        String responseContent = HttpUtils.post(body, vaultGetewayUrlValue + "/security/secret/queryDefaultPlaintextBySecretAlias", headers);
        JsonNode jsonObject;
        try {
            jsonObject = OBJECT_MAPPER.readTree(responseContent);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        String status = jsonObject.get("head").get("status").textValue();
        if (!"Y".equals(status)) {
            log.error("Calling vault to decrypt text failed, http response msg [{}]", jsonObject.get("head").get("msg").textValue());
            throw new RuntimeException("Calling vault to decrypt text failed");
        }
        return jsonObject.get("body").textValue();
    }

    public String getSignature(long timestamp, String nonce) {
        HashMap<String, String> params = new HashMap<>();
        params.put(VERSION, VERSION_VALUE);
        params.put(TIMESTAMP, Long.toString(timestamp));
        params.put(APPKEY, vaultGetewayAppkeylValue);
        params.put(XREQNONCE, nonce);
        TreeMap<String, String> treeMap = new TreeMap<>();
        treeMap.put(APPSECRET, vaultGetewayAppsecretValue);
        for (Map.Entry<String, String> entry : params.entrySet()) {
            treeMap.put(entry.getKey(), entry.getValue());
        }
        StringBuilder builder = new StringBuilder();
        for (Object parameter : treeMap.values()) {
            if (parameter != null) {
                builder.append(parameter.toString());
            }
        }
        String signStr = null;
        try {
            HmacSHA256Signature signature = new HmacSHA256Signature();
            signStr = signature.sign(URLEncoder.encode(builder.toString(), "UTF-8"), vaultGetewayAppsecretValue);
        } catch (UnsupportedEncodingException e) {
            log.error("get signature failed", e);
        }
        return signStr;
    }

}
